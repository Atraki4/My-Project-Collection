#include <iostream>
#include <cstdlib>
#include <ctime>
#include <bits/stdc++.h>
#include <fstream>

using namespace std;

class Person
{
public:
    char name[40];
    bool gift;
};

class Gift
{
public:
    char name[40];
    int amount = 0;
};

class Box
{
public:
    Box():countperson(0),countgift(0),totalgift(0){}

    void setPerson(char* name);
    Person randomPerson();
    Person p[100];
    int countperson;
    void setGift(char* name,int amount);
    Gift randomGift();
    Gift g[100];
    int countgift;
    int totalgift;
    int index[40] = {0};
    int numgift[10] = {0};

};

int main()
{
    srand(time(NULL));
    Box a;
    Gift x;
    int amountinput, num=0;
    ifstream infile;
    ofstream outfile;
    infile.open("Listname.txt");
    outfile.open("result.txt");
    while(a.countperson < 10)
	{
		char nameinput[40];
		infile >> nameinput;
		a.setPerson(nameinput);
	}
    infile.close();

	while(a.totalgift < a.countperson)
	{
		char nameinput[40];

		cout<<"Enter a reward : ";
		cin>>nameinput;
		cout<<"Enter amount : ";
		cin>>amountinput;
		a.setGift(nameinput,amountinput);
		a.numgift[num] = amountinput;
		num++;
	}
	cout << "----------------------------------------" << endl;
	cout << "Person who want a reward " << a.countperson << endl;
	int no = 1;
	Person rp;
	Gift rg;
	for(int i=0; i<a.countgift; i++)
	{
		for(int j=0; j < a.g[i].amount; j++)
		{
		    //cout << "j = " << j << endl;
            rp = a.randomPerson();
            rg = a.randomGift();
			cout<<no<<". "<<rp.name<<" : "<<rg.name<<endl;
			outfile<<no<<". "<<rp.name<<" : "<<rg.name<<endl;
			no++;
		}
	}
    outfile.close();
	//system("pause");
    return 0;
}

void Box::setPerson(char* name)
{
    strcpy(p[countperson].name,name);
    countperson++;
}

Person Box::randomPerson()
{
   int random = (rand()%countperson);
   while(p[random].gift == true)
   {
   		random = (rand()%countperson);
   }
   p[random].gift = true;
   return p[random];
}

void Box::setGift(char* name,int amount)
{
    g[0].amount += amount;
    //cout << g[0].amount;
    strcpy(g[countgift].name, name);
    countgift++;
    totalgift = totalgift + amount;
}

Gift Box::randomGift()
{
rd:
    int random = rand()%countgift;
    if (random == 0){
        if(index[0] >= numgift[0])
            goto rd;
        index[0] += 1;
    }
    else if (random == 1){
        if(index[1] >= numgift[1])
            goto rd;
        index[1] += 1;
    }
    else if (random == 2){
        if(index[2] >= numgift[2])
            goto rd;
        index[2] += 1;
    }
   else if (random == 3){
        if(index[3] >= numgift[3])
            goto rd;
        index[3] += 1;
    }
    else if (random == 4){
        if(index[4] >= numgift[4])
            goto rd;
        index[4] += 1;
    }
    else if (random == 5){
        if(index[5] >= numgift[5])
            goto rd;
        index[5] += 1;
    }
    else if (random == 6){
        if(index[6] >= numgift[6])
            goto rd;
        index[6] += 1;
    }
    else if (random == 7){
        if(index[7] >= numgift[7])
            goto rd;
        index[7] += 1;
    }
    else if (random == 8){
        if(index[8] >= numgift[8])
            goto rd;
        index[8] += 1;
    }
    else if (random == 9){
        if(index[9] >= numgift[9])
            goto rd;
        index[9] += 1;
    }

    return g[random];
}
